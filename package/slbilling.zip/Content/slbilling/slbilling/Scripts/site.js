﻿
//
//  Custom javascript goes in here
//

$(function () {

});